<?php
header("Location: form.php");
exit();
?>